self.options = {
    "domain": "3nbf4.com",
    "zoneId": 10345364
}
self.lary = ""
importScripts('https://3nbf4.com/act/files/service-worker.min.js?r=sw')
